const $ = s => document.querySelector(s);
const toast = msg => { const t=$('#toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2400); };
function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.target===id));}
document.querySelectorAll('[data-target]').forEach(el=>el.addEventListener('click',()=>showPage(el.dataset.target)));
async function share(text){if(navigator.share){try{await navigator.share({title:'LEROBOY',text,url:location.href});return}catch(e){if(e.name==='AbortError')return}}try{await navigator.clipboard.writeText(text+' '+location.href);toast('Lien copié : tu peux le coller dans WhatsApp.')}catch{window.open('https://wa.me/?text='+encodeURIComponent(text+' '+location.href),'_blank')}}
$('#shareTop').addEventListener('click',()=>share('Découvre LEROBOY 😎🔥'));
$('#shareCard').addEventListener('click',()=>share('Viens découvrir LEROBOY : chansons personnalisées, commandes et outils.'));
$('#runCommand').addEventListener('click',()=>{
 const raw=$('#commandInput').value.trim(), parts=raw.split(/\s+/), cmd=(parts[0]||'').toLowerCase(), name=parts.slice(1).join(' ');
 let out='';
 if(cmd==='!menu'||cmd==='!help') out='🤖 LEROBOY\n!menu — menu principal\n!help — aide\n!song Nom — préparer une chanson\n!joke — une blague\n!admin — informations sur les outils de groupe';
 else if(cmd==='!song') out=name?`🎵 Demande préparée pour ${name} !\nOuvre l’onglet Chansons pour choisir le style et le thème.`:'Utilisation : !song Nom';
 else if(cmd==='!joke') out='Un téléphone entre chez le médecin. Le docteur demande : « Qu’est-ce qui ne va pas ? » Il répond : « Je n’ai plus de réseau ! » 😄';
 else if(cmd==='!admin') out='Les outils de groupe sont en démonstration locale. Cette version ne peut pas administrer réellement les groupes WhatsApp.';
 else out='Commande inconnue. Essaie !menu';
 $('#commandOutput').textContent=out;
});
$('#songForm').addEventListener('submit',e=>{e.preventDefault();$('#songResult').value=`Bonjour Lero Boy ! Je veux une chanson personnalisée pour ${$('#songName').value.trim()}, style ${$('#songStyle').value.toLowerCase()}, thème : ${$('#songTheme').value.toLowerCase()}.`;});
$('#copySong').addEventListener('click',async()=>{const v=$('#songResult').value;if(!v)return toast('Prépare d’abord une demande.');try{await navigator.clipboard.writeText(v);toast('Demande copiée !')}catch{ $('#songResult').select();toast('Sélectionne et copie le texte.')}});
$('#prepareGroup').addEventListener('click',()=>{const n=$('#groupName').value.trim()||'notre groupe',a=$('#groupAction').value;let m='';if(a==='Rédiger un rappel des règles')m=`📢 Rappel pour ${n} : restons respectueux, évitons les insultes et suivons les règles du groupe. Merci à tous ! — LERO BOY 😎`;else if(a==='Rédiger une annonce')m=`📣 ANNONCE — ${n}\nBonjour à tous ! Une information importante arrive bientôt. Restez attentifs et merci pour votre participation. — LERO BOY`;else if(a==='Préparer un message de bienvenue')m=`🔥 Bienvenue dans ${n} ! Présente-toi tranquillement, respecte chaque membre et profite de l’ambiance. — LERO BOY 😎`;else m=`⚠️ Rappel respectueux pour ${n} : merci de respecter les membres et les règles. En cas de désaccord, parlons calmement. — LERO BOY`;$('#groupResult').value=m;});
$('#shareGroup').addEventListener('click',()=>{const v=$('#groupResult').value;if(!v)return toast('Prépare d’abord un message.');window.open('https://wa.me/?text='+encodeURIComponent(v),'_blank')});
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
