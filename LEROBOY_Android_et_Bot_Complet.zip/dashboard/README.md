# Younoussa LERO BOY — Android/PWA + bot starter

Ce projet contient :
- une interface mobile installable sur Android (PWA) en noir et rouge ;
- un tableau de bord avec accueil, partage WhatsApp, commandes, chansons personnalisées et gestion de groupe en mode démonstration ;
- un serveur Node.js de départ pour les webhooks de WhatsApp Cloud API.

## Démarrer l'application mobile (interface)

La PWA doit être servie en HTTPS pour être installable depuis Chrome (sauf localhost).
Pour un test rapide sur ordinateur :
1. Installe Node.js 18 ou plus récent.
2. Dans le dossier `server`, lance `npm install`.
3. Lance `npm start`.
4. Ouvre `http://localhost:3000`.

Pour l'installer sur ton téléphone Android :
1. Héberge le dossier `public` sur un hébergement HTTPS, ou déploie tout le projet sur un hébergeur Node.js.
2. Ouvre l'URL HTTPS dans Chrome sur Android.
3. Menu ⋮ → **Installer l'application** ou **Ajouter à l'écran d'accueil**.

## Activer le bot WhatsApp officiel

L'interface fonctionne en démonstration sans compte WhatsApp. Le serveur webhook est un squelette d'intégration à WhatsApp Cloud API :
1. Crée une application dans Meta for Developers et configure WhatsApp Cloud API.
2. Ajoute les variables d'environnement du fichier `.env.example`.
3. Configure l'URL HTTPS du serveur comme webhook dans Meta et utilise le même `VERIFY_TOKEN`.
4. Ajoute le jeton d'accès et l'identifiant du numéro fournis par Meta.

**Important :** ce projet n'est pas connecté à WhatsApp tant que tu n'as pas configuré les identifiants Meta. N'envoie jamais ton jeton d'accès ou tes codes de connexion à quelqu'un.

## Limites importantes

- L'API officielle WhatsApp Business permet certains échanges avec les utilisateurs, mais elle ne fournit pas les fonctions générales d'administration de groupes WhatsApp personnels. La section « Groupes » de cette version est donc une maquette locale, pas un contrôle réel de tes groupes.
- Le bot ne peut pas envoyer librement des messages à tout le monde : les règles WhatsApp Business, les consentements et les modèles de messages s'appliquent.
- Ce projet ne récupère pas les codes de jumelage WhatsApp et n'utilise pas de bibliothèques non officielles qui risqueraient de faire bloquer ton compte.
- Le projet est un starter source ; ce ZIP n'est pas un APK compilé.

## Commandes de démonstration

Dans l'application, teste `!menu`, `!help`, `!song Rachida`, `!joke`.
