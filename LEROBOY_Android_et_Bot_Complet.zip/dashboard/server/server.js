require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN || 'change-moi-pour-un-secret-aleatoire';

app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

app.post('/webhook', async (req, res) => {
  // Répond rapidement à Meta. Le traitement réel se fait après réception.
  res.sendStatus(200);
  try {
    const entries = req.body?.entry || [];
    for (const entry of entries) {
      for (const change of (entry.changes || [])) {
        const value = change.value || {};
        for (const message of (value.messages || [])) {
          const from = message.from;
          const body = message.text?.body?.trim() || '';
          if (!from || !body) continue;
          const answer = commandReply(body);
          if (answer) await sendText(from, answer);
        }
      }
    }
  } catch (err) {
    console.error('Erreur webhook:', err.message);
  }
});

function commandReply(body) {
  const [cmd, ...rest] = body.trim().split(/\s+/);
  const name = rest.join(' ');
  switch ((cmd || '').toLowerCase()) {
    case '!menu':
    case '!help':
      return '🤖 YOUNOUSSA LERO BOY\\n!menu — menu\\n!song Nom — demande de chanson\\n!joke — blague\\nRéponds avec une commande pour continuer.';
    case '!song':
      return name ? `🎵 Demande reçue pour ${name}. LERO BOY préparera une chanson personnalisée !` : 'Utilisation : !song Nom';
    case '!joke':
      return 'Pourquoi le téléphone est-il allé à l’école ? Pour améliorer sa réception ! 😄';
    case '!admin':
      return 'Les commandes d’administration générale des groupes ne sont pas disponibles via cette API officielle.';
    default:
      return null;
  }
}

async function sendText(to, text) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneNumberId = process.env.PHONE_NUMBER_ID;
  const version = process.env.GRAPH_API_VERSION || 'v22.0';
  if (!token || !phoneNumberId) {
    console.warn('Message non envoyé : configure WHATSAPP_TOKEN et PHONE_NUMBER_ID dans .env');
    return;
  }
  const response = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to,
      type: 'text',
      text: { preview_url: false, body: text }
    })
  });
  if (!response.ok) console.error('Erreur envoi WhatsApp:', response.status, await response.text());
}

app.listen(PORT, () => console.log(`Younoussa LERO BOY prêt sur le port ${PORT}`));
