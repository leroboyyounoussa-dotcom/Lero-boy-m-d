# Bot LEROBOY — base importée

Le dossier contient le bot fourni par l'utilisateur, avec les valeurs par défaut du nom et du propriétaire réglées sur **Younoussa LERO BOY**.

## Installation sur un hébergement Node.js
1. Utilise Node.js 20 ou une version compatible.
2. Ouvre le dossier `bot/LEROBOY`.
3. Installe les dépendances avec `npm install`.
4. Copie `config.env.example` vers `config.env` et configure les paramètres nécessaires.
5. Démarre selon les instructions du projet et les exigences de l'hébergeur.

## Sécurité
- `SESSION_ID` est un secret de connexion. Ne le poste pas, ne l'envoie pas et ne l'inclus pas dans une capture.
- Le fichier `index.js` fourni est fortement obfusqué. Son comportement complet n'a pas pu être audité. Ne lui donne pas de secrets ou d'accès sensibles avant de faire vérifier le code par une personne compétente.
- Ce bot utilise Baileys, une bibliothèque non officielle pour WhatsApp Web. Son utilisation peut entraîner des restrictions ou un blocage du compte. Le tableau de bord fourni dans `dashboard/` est séparé du bot : il n'est pas encore connecté à ses commandes en direct.
- Les fonctions de commandes de groupe dépendent de ce que permet le code importé. L'interface ne contourne pas les protections de WhatsApp.
