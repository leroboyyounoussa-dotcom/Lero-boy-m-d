# LEROBOY — projet Android + bot

## Ce qui est inclus
- `android-app/` : projet Android natif (WebView) pour créer une application installable nommée **LEROBOY**. Le tableau de bord fonctionne localement, sans hébergement pour son interface.
- `dashboard/` : version web/PWA et serveur de départ.
- `bot/LEROBOY/` : fichiers du bot que tu avais fournis, renommés autant que possible en LEROBOY, avec configuration d'exemple.
- `.github/workflows/android-apk.yml` : génération automatique d'un APK de test via GitHub Actions.

## Important : ce ZIP n'est pas lui-même un APK
L'environnement de création n'a pas le SDK Android installé, donc aucun APK compilé n'est inclus. Pour obtenir l'APK : importe ce dossier dans un dépôt GitHub, ouvre l'onglet **Actions**, lance **Build LEROBOY APK**, puis télécharge l'artefact `LEROBOY-Android-APK`. L'APK debug est destiné aux tests et n'est pas signé pour une publication Play Store.

## Installer sur Android
Après avoir récupéré l'APK, ouvre-le sur ton téléphone et autorise l'installation depuis la source que tu as utilisée, si Android le demande. N'installe que ton propre fichier et évite les APK envoyés par des inconnus.

## Limites actuelles
- L'application Android contient le tableau de bord local : commandes affichées/démonstration, préparation de chansons et outils de rédaction. Elle n'est pas encore reliée au bot WhatsApp en direct.
- Renommer les fichiers de configuration ne modifie pas forcément toutes les chaînes cachées dans `index.js`, qui est obfusqué.
- Le bot utilise une bibliothèque WhatsApp Web non officielle (Baileys), susceptible d'entraîner des restrictions de compte. Le code obfusqué n'a pas pu être entièrement audité. N'y ajoute pas de code de session ni de mot de passe dans le ZIP. Pour un usage de production, privilégie l'API officielle WhatsApp Business Platform.
- `OWNER_NUMBER` est laissé vide dans la configuration : renseigne ton numéro uniquement dans ton environnement privé si tu décides d'utiliser le bot.
